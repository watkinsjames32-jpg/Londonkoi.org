require 'sinatra'
require 'json'
require 'stripe'
# This is your test secret API key.
# Don't put any keys in code. See https://docs.stripe.com/keys-best-practices.
client = Stripe::StripeClient.new('sk_test_51TzGI6P7jSnnw4xUZzYU7MhPFHuepoDFCNxaTsFy9A5tKeHaGNvzL6rUo7SeuHKv4oHEUTZqZymubg9jTwoyJ8dJ00tw60p6a2')

# To run this example, set an environment variable STRIPE_WEBHOOK_SECRET to
# your endpoint's unique secret.
#
# If you are testing with the CLI, find the secret by running 'stripe listen'.
# If you are using an endpoint defined with the API or dashboard, look in
# your webhook settings at https://dashboard.stripe.com/webhooks.
#
# Don't include webhook secrets in code.
endpoint_secret = ENV['STRIPE_WEBHOOK_SECRET']


set :port, 4242

post '/webhook' do
  payload = request.body.read
  event = nil

  begin
    event = Stripe::Event.construct_from(
      JSON.parse(payload, symbolize_names: true)
    )
  rescue JSON::ParserError => e
    # Invalid payload
    puts "⚠️  Webhook error while parsing basic request. #{e.message}"
    status 400
    return
  end
  # Check if webhook signing is configured.
  if endpoint_secret
    # Retrieve the event by verifying the signature using the raw body and secret.
    signature = request.env['HTTP_STRIPE_SIGNATURE'];
    begin
      event = Stripe::Webhook.construct_event(
        payload, signature, endpoint_secret
      )
    rescue Stripe::SignatureVerificationError => e
      puts "⚠️  Webhook signature verification failed. #{e.message}"
      status 400
    end
  end

  # Handle the event
  case event.type
  when 'payment_intent.succeeded'
    payment_intent = event.data.object # contains a Stripe::PaymentIntent
    puts "Payment for #{payment_intent['amount']} succeeded."
    # Then define and call a method to handle the successful payment intent.
    # handle_payment_intent_succeeded(payment_intent)
  when 'payment_method.attached'
    payment_method = event.data.object # contains a Stripe::PaymentMethod
    # Then define and call a method to handle the successful attachment of a PaymentMethod.
    # handle_payment_method_attached(payment_method)
  else
    puts "Unhandled event type: #{event.type}"
  end
  status 200
end